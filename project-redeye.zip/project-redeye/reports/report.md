# Recon Report for `redeye-demo.com`

- Generated: 2025-09-07T00:09:42Z
- Tools: {"amass": "not found", "sublist3r": "not found", "nmap": "not found"}
- Note: Only assess systems you are authorized to test.

_No findings yet. Run `python redeye.py <domain>` to populate this report._

## Example (remove after first real run)

### www.redeye-demo.com
- IPs: 93.184.216.34

| Port | Proto | State | Service | Product |
|---:|:---:|:---:|:---|:---|
| 443 | tcp | open | https | nginx |
