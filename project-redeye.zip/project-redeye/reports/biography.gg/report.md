# Recon Report for `biography.gg`

- Generated: 2025-09-07T00:14:35Z
- Tools: {"amass": "not found", "sublist3r": "not found", "nmap": "not found"}
- Note: Only assess systems you are authorized to test.

## api.biography.gg

- IPs: 216.24.57.251, 216.24.57.7

| Port | Proto | State | Service | Product |
|---:|:---:|:---:|:---|:---|
| 80 | tcp | open |  |  |
| 443 | tcp | open |  |  |
| 2082 | tcp | open |  |  |
| 2083 | tcp | open |  |  |
| 8080 | tcp | open |  |  |
| 8443 | tcp | open |  |  |

## biography.gg

- IPs: 104.18.16.133, 104.18.17.133, 2606:4700::6812:1085, 2606:4700::6812:1185

| Port | Proto | State | Service | Product |
|---:|:---:|:---:|:---|:---|
| 80 | tcp | open |  |  |
| 443 | tcp | open |  |  |
| 2082 | tcp | open |  |  |
| 2083 | tcp | open |  |  |
| 8080 | tcp | open |  |  |
| 8443 | tcp | open |  |  |

